<?php


    ob_start();
    session_start();

    
    require_once __DIR__ . '/libary.php';


    require_once __DIR__ . '/header.php';


    if ( @$_SESSION['Id'] == TRUE ) {

        @$session_user = queryid (" SELECT IdLogin AS Id, Nama, Level FROM Tbl_Login WHERE IdLogin = '". @$_SESSION['Id'] ."' ORDER BY IdLogin DESC LIMIT 1 ");

        require_once __DIR__ . '/admin/index.php';

        if ( @$_GET['__Logout'] == TRUE ) {

            @$_SESSION = array();
            session_destroy();
            
            echo "<script>
                    alert('Berhasil Logout');
                    document.location.href = '". base_url() ."';
                </script>";

        }

    } else {

        require_once __DIR__ . '/login.php';

    }


    require_once __DIR__ . '/footer.php'; 