<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6 col-lg-6 col-md-10">
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">
                                        Selamat Datang !
                                    </h1>
                                </div>
                                <form class="user" name="frmInput" action="" method="POST"
                                    enctype="multipart/form-data">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" placeholder="Username"
                                            name="__Username" autocomplete="off" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user"
                                            placeholder="Password" name="__Password" autocomplete="off" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-user btn-block" name="__BtnLogin">
                                        Login
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php 


    if ( isset( $_POST['__BtnLogin'] ) ) {

        if ( @$_POST['__Username'] == TRUE AND @$_POST['__Password'] == TRUE ) {

            @$__session_login = queryid (" SELECT IdLogin AS Id, Nama, Level FROM Tbl_Login WHERE Username = '". @$_POST['__Username'] ."' AND Password = '". @$_POST['__Password'] ."' ORDER BY IdLogin DESC LIMIT 1 ");

            if ( @$__session_login->Id == TRUE ) {

                @$_SESSION['Id'] = @$__session_login->Id;

                echo "<script>
                        alert('Selamat Datang ". @$__session_login->Nama ." Sebagai Status ". @$__session_login->Level ."!');
                        document.location.href = '". base_url() ."';
                    </script>";
                
            } else {

                echo "<script>
                        alert('Data Tidak Terdaftar');
                        document.location.href = '". base_url() ."';
                    </script>";

            }

        } else {

            echo "<script>
                    alert('Masukkan Username & Password Dengan Benar');
                    document.location.href = '". base_url() ."';
                </script>";

        }

    }
    
    
?>