<?php


    date_default_timezone_set('Asia/Jakarta');


    function base_url(){

        $base = 'http://sjf.test/';

        return $base;

    }



    try {

		@$connection = new PDO( 'mysql:host=localhost; dbname=SJF', 'root', '' );
        @$connection -> exec( 'set names utf8' );
        @$connection -> setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

    } catch ( PDOException $error ) {

        print "Koneksi Database : " . $error->getMessage() . "<br/>";
		die();

    }




    function query ( $data_tampil ) {

        global $connection;

            $row_data       = $connection->prepare( $data_tampil );
            $row_data->execute();
            $datas          = [];
            while ( $data_tampil = $row_data->fetch(PDO::FETCH_OBJ) ) :
                $datas[]    = $data_tampil;
            endwhile;
        
        return $datas;

    }

    function queryid ( $data_tampil ) {

        global $connection;

            $row_data       = $connection->prepare( $data_tampil );
            $row_data->execute();
            $data_tampil    = $row_data->fetch(PDO::FETCH_OBJ);
            $datas[]        = $data_tampil;
        
        return $data_tampil;

    }




    if ( !function_exists ('__Tabel_Guru') ) {
        function __Tabel_Guru ( $crud, $id, $data ) {

            global $connection;

                if ( @$crud == 'Tambah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Login (
                                Username, Password, Nama, Level
                            ) VALUES (
                                :Username, :Password, :Nama, :Level
                            )
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Ubah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Login SET
                                Username        = :Username, 
                                Password        = :Password,
                                Nama            = :Nama
                            WHERE IdLogin       = :Id
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Hapus' ) {

                    @$query = @$connection -> prepare( 
                            "
                                DELETE FROM Tbl_Login
                                WHERE IdLogin = :Id
                            "
                    ) -> execute ( @$data );

                }

                if ( @$query == TRUE ) {

                    @$respon    = '200';

                } else {

                    @$respon    = '400';

                }

            return @$respon;

        }
    }

    if ( !function_exists ('__Tabel_Siswa') ) {
        function __Tabel_Siswa ( $crud, $id, $data ) {

            global $connection;

                if ( @$crud == 'Tambah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Login (
                                Username, Password, Nama, Level
                            ) VALUES (
                                :Username, :Password, :Nama, :Level
                            )
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Ubah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Login SET
                                Username        = :Username, 
                                Password        = :Password,
                                Nama            = :Nama
                            WHERE IdLogin       = :Id
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Hapus' ) {

                    @$query = @$connection -> prepare( 
                            "
                                DELETE FROM Tbl_Login
                                WHERE IdLogin = :Id
                            "
                    ) -> execute ( @$data );

                }

                if ( @$query == TRUE ) {

                    @$respon    = '200';

                } else {

                    @$respon    = '400';

                }

            return @$respon;

        }
    }

    if ( !function_exists ('__Tabel_Kasus') ) {
        function __Tabel_Kasus ( $crud, $id, $data ) {

            global $connection;

                if ( @$crud == 'Tambah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Kasus (
                                Kode_Kasus, Nama_Kasus, Eksekusi_Kasus
                            ) VALUES (
                                :Kode, :Nama, :Eksekusi
                            )
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Ubah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Kasus SET
                                Kode_Kasus      = :Kode, 
                                Nama_Kasus      = :Nama,
                                Eksekusi_Kasus  = :Eksekusi
                            WHERE Id_Kasus      = :Id
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Hapus' ) {

                    @$query = @$connection -> prepare( 
                            "
                                DELETE FROM Tbl_Kasus
                                WHERE Id_Kasus = :Id
                            "
                    ) -> execute ( @$data );

                }

                if ( @$query == TRUE ) {

                    @$respon    = '200';

                } else {

                    @$respon    = '400';

                }

            return @$respon;

        }
    }

    if ( !function_exists ('__Tabel_Jadwal') ) {
        function __Tabel_Jadwal ( $crud, $id, $data ) {

            global $connection;

                if ( @$crud == 'Tambah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Jadwal (
                                Id_Kasus, Tgl_Jadwal, JamMulai_Jadwal, JamSelesai_Jadwal, Status_Jadwal
                            ) VALUES (
                                :Id_Kasus, :Tanggal, :Jam_Mulai, :Jam_Selesai, :Status
                            )
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Ubah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Jadwal SET
                                Id_Kasus        = :Id_Kasus
                            WHERE Id_Jadwal     = :Id
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Hapus' ) {

                    @$query = @$connection -> prepare( 
                            "
                                DELETE FROM Tbl_Jadwal
                                WHERE Id_Jadwal = :Id
                            "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Aktif' ) {

                    @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Jadwal SET
                                Status_Jadwal   = 'Aktif'
                            WHERE Id_Jadwal     = :Id
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Tidak Aktif' ) {

                    @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Jadwal SET
                                Status_Jadwal   = 'Tidak Aktif'
                            WHERE Id_Jadwal     = :Id
                        "
                    ) -> execute ( @$data );

                }

                if ( @$query == TRUE ) {

                    @$respon    = '200';

                } else {

                    @$respon    = '400';

                }

            return @$respon;

        }
    }

    if ( !function_exists ('__Tabel_Curhat') ) {
        function __Tabel_Curhat ( $crud, $id, $data ) {

            global $connection;

                if ( @$crud == 'Tambah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Curhat (
                                Id_Jadwal, Id_Kasus, Tgl_Curhat, Id_Siswa, Id_Guru, Status_Curhat
                            ) VALUES (
                                :Id_Jadwal, :Id_Kasus, :Tanggal, :Id_Siswa, :Id_Guru, :Status
                            )
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Hapus' ) {

                    @$query = @$connection -> prepare( 
                            "
                                DELETE FROM Tbl_Curhat
                                WHERE Id_Curhat = :Id
                                AND Id_Jadwal   = :Id_Jadwal
                            "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Tolak' ) {

                    @$query = @$connection -> prepare( 
                            "
                                UPDATE Tbl_Curhat SET
                                    Status_Curhat   = :Status
                                WHERE Id_Curhat     = :Id
                                AND Id_Jadwal       = :Id_Jadwal
                            "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Validasi' ) {

                    @$query = @$connection -> prepare( 
                            "
                                UPDATE Tbl_Curhat SET
                                    Status_Curhat   = :Status
                                WHERE Id_Curhat     = :Id
                                AND Id_Jadwal       = :Id_Jadwal
                            "
                    ) -> execute ( @$data );

                }

                if ( @$query == TRUE ) {

                    @$respon    = '200';

                } else {

                    @$respon    = '400';

                }

            return @$respon;

        }
    }

    if ( !function_exists ('__Tabel_Konseling') ) {
        function __Tabel_Konseling ( $crud, $id, $data ) {

            global $connection;

                if ( @$crud == 'Tambah' ) {

                    @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Konseling (
                                Pesan, Tanggal, Id_Siswa, Id_Guru, Id_Curhat
                            ) VALUES (
                                :Pesan, :Tanggal, :Id_Siswa, :Id_Guru, :Id_Curhat
                            )
                        "
                    ) -> execute ( @$data );

                } elseif ( @$crud == 'Hapus' ) {

                    @$query = @$connection -> prepare( 
                            "
                                DELETE FROM Tbl_Curhat
                                WHERE Id_Konseling  = :Id_Konseling
                                AND Id_Curhat       = :Id
                            "
                    ) -> execute ( @$data );

                } 

                if ( @$query == TRUE ) {

                    @$respon    = '200';

                } else {

                    @$respon    = '400';

                }

            return @$respon;

        }
    }