<?php 

    @$__session_total_1 = queryid (" SELECT COUNT( IdLogin ) AS Total FROM Tbl_Login WHERE Level = 'Guru' ");
    @$__session_total_2 = queryid (" SELECT COUNT( IdLogin ) AS Total FROM Tbl_Login WHERE Level = 'Siswa' ");
    @$__session_total_3 = queryid (" SELECT COUNT( Id_Kasus ) AS Total FROM Tbl_Kasus ");
    @$__session_total_4 = queryid (" SELECT COUNT( Id_Jadwal ) AS Total FROM Tbl_Jadwal WHERE Tgl_Jadwal = '". date('Y-m-d') ."' ");

?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">
        Selamat Datang, <?= @$session_user->Nama; ?>
        <br>
        <small>
            Sebagai, <?= @$session_user->Level; ?>
        </small>
    </h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
        <i class="fas fa-download fa-sm text-white-50"></i>
        Generate Report
    </a>
</div>
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Guru
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= @$__session_total_1->Total; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Siswa
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= @$__session_total_2->Total; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Total Curhat
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= @$__session_total_3->Total; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Total Jadwal Hari Ini
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= @$__session_total_4->Total; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-comments fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if ( @$session_user->Level == 'Siswa' ) { ?>

<div class="row">
    <div class="col-xl-12 col-md-12 mb-4">
        <div class="card">
            <div class="card-header">
                <a href="?__Module=LihatJadwal">
                    Jadwal Curhat
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table text-center" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nomor</th>
                                <th>Nama Kasus</th>
                                <th>Tanggal</th>
                                <th>Jam Curhat</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php 
                            
                                @$nomor = '1';

                                @$session_item = query (" SELECT Id_Jadwal AS Id, Id_Kasus, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2, Status_Jadwal AS Status FROM Tbl_Jadwal WHERE Status_Jadwal = 'Aktif' ORDER BY JamMulai_Jadwal DESC LIMIT 5 ");

                                    foreach ( $session_item AS $data => $item ) :

                                        @$data_kasus = queryid (" SELECT Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");
                            
                            ?>

                            <tr>
                                <td>
                                    <?= @$nomor++; ?>
                                </td>
                                <td>
                                    <?= @$data_kasus->Nama; ?>
                                </td>
                                <td>
                                    <?= date('d M Y', strtotime( @$item->Tgl )); ?>
                                </td>
                                <td>
                                    <?= date('H:i', strtotime( @$item->Jam1 )); ?> -
                                    <?= date('H:i', strtotime( @$item->Jam2 )); ?>
                                </td>
                            </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php } ?>


<?php if ( @$session_user->Level == 'Guru' ) { ?>

<div class="row">
    <div class="col-xl-12 col-md-12 mb-4">
        <div class="card">
            <div class="card-header">
                <a href="?__Module=JadwalBimbingan">
                    Jadwal Bimbingan Curhat
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table text-center" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nomor</th>
                                <th>Nama Kasus</th>
                                <th>Tanggal</th>
                                <th>Jam Curhat</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php 
                            
                                @$nomor = '1';

                                @$session_item = query (" SELECT Id_Jadwal AS Id, Id_Kasus, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2, Status_Jadwal AS Status FROM Tbl_Jadwal ORDER BY JamMulai_Jadwal DESC LIMIT 5 ");

                                    foreach ( $session_item AS $data => $item ) :

                                        @$data_kasus = queryid (" SELECT Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                                        @$data_curhat = queryid (" SELECT Id_Guru AS Id FROM Tbl_Curhat WHERE Id_Jadwal = '". @$item->Id ."' AND Id_Guru = '". @$session_user->Id ."' ORDER BY Id_Curhat DESC LIMIT 1 ");

                                            if ( @$data_curhat->Id == @$session_user->Id ) {
                            
                            ?>

                            <tr>
                                <td>
                                    <?= @$nomor++; ?>
                                </td>
                                <td>
                                    <?= @$data_kasus->Nama; ?>
                                </td>
                                <td>
                                    <?= date('d M Y', strtotime( @$item->Tgl )); ?>
                                </td>
                                <td>
                                    <?= date('H:i', strtotime( @$item->Jam1 )); ?> -
                                    <?= date('H:i', strtotime( @$item->Jam2 )); ?>
                                </td>
                            </tr>

                            <?php } endforeach; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php } ?>