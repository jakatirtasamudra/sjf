<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url(); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">
            Metode <sup>SJF</sup>
        </div>
    </a>
    <hr class="sidebar-divider my-0">
    <li class="nav-item active">
        <a class="nav-link" href="<?= base_url(); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>
                Dashboard
            </span>
        </a>
    </li>
    <hr class="sidebar-divider">

    <?php if ( @$session_user->Level == 'Admin' ) { ?>
    <div class="sidebar-heading">
        Data Admin
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse-DataAdmin"
            aria-expanded="true" aria-controls="collapse-DataAdmin">
            <i class="fas fa-fw fa-cog"></i>
            <span>
                Master
            </span>
        </a>
        <div id="collapse-DataAdmin"
            class="collapse <?php if ( @$_GET['__Module'] == 'Guru' OR @$_GET['__Module'] == 'Siswa' OR @$_GET['__Module'] == 'Kasus' ) { echo 'show'; } ?>"
            aria-labelledby="heading-DataAdmin" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php if ( @$_GET['__Module'] == 'Guru' ) { echo 'active'; } ?>"
                    href="?__Module=Guru">
                    Guru
                </a>
                <a class="collapse-item <?php if ( @$_GET['__Module'] == 'Siswa' ) { echo 'active'; } ?>"
                    href="?__Module=Siswa">
                    Siswa
                </a>
                <a class="collapse-item <?php if ( @$_GET['__Module'] == 'Kasus' ) { echo 'active'; } ?>"
                    href="?__Module=Kasus">
                    Kasus
                </a>
            </div>
        </div>
    </li>
    <?php } ?>

    <?php if ( @$session_user->Level == 'Siswa' ) { ?>
    <div class="sidebar-heading">
        Data Siswa
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse-DataSiswa"
            aria-expanded="true" aria-controls="collapse-DataSiswa">
            <i class="fas fa-fw fa-cog"></i>
            <span>
                Jadwal
            </span>
        </a>
        <div id="collapse-DataSiswa"
            class="collapse <?php if ( @$_GET['__Module'] == 'LihatJadwal' OR @$_GET['__Module'] == 'Konseling' ) { echo 'show'; } ?>"
            aria-labelledby="heading-DataSiswa" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php if ( @$_GET['__Module'] == 'LihatJadwal' OR @$_GET['__Module'] == 'Konseling' ) { echo 'active'; } ?>"
                    href="?__Module=LihatJadwal">
                    Lihat Jadwal
                </a>
            </div>
        </div>
    </li>
    <?php } ?>

    <?php if ( @$session_user->Level == 'Guru' ) { ?>
    <div class="sidebar-heading">
        Data Guru
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse-DataGuru"
            aria-expanded="true" aria-controls="collapse-DataGuru">
            <i class="fas fa-fw fa-cog"></i>
            <span>
                Jadwal
            </span>
        </a>
        <div id="collapse-DataGuru"
            class="collapse <?php if ( @$_GET['__Module'] == 'JadwalBimbingan' OR @$_GET['__Module'] == 'Konseling' ) { echo 'show'; } ?>"
            aria-labelledby="heading-DataSiswa" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php if ( @$_GET['__Module'] == 'JadwalBimbingan' OR @$_GET['__Module'] == 'Konseling' ) { echo 'active'; } ?>"
                    href="?__Module=JadwalBimbingan">
                    Bimbingan
                </a>
            </div>
        </div>
    </li>
    <?php } ?>

    <li class="nav-item">
        <a class="nav-link" href="?__Module=Sjf">
            <i class="fas fa-fw fa-clock"></i>
            <span>
                Shortest Job First
            </span>
        </a>
    </li>

    <?php if ( @$session_user->Level == 'Guru' OR @$session_user->Level == 'Siswa' ) { ?>
    <li class="nav-item">
        <a class="nav-link" href="?__Module=Laporan">
            <i class="fas fa-fw fa-print"></i>
            <span>
                Laporan
            </span>
        </a>
    </li>
    <?php } ?>

    <hr class="sidebar-divider d-none d-md-block">
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>