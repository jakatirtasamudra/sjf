<h1 class="h3 mb-2 text-gray-800">
    Metode Shortest Job First
</h1>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data SJF
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Nama Proses</th>
                        <th>Waktu Tiba</th>
                        <th>Lama Eksekusi</th>
                    </tr>
                </thead>
                <tbody>

                    <?php 

                        @$__array_sjf   = [];
                        @$nomor     = '1';
                        @$__proses  = '1';

                        @$session_item = query (" SELECT Id_Curhat AS Id, Id_Kasus, Id_Jadwal FROM Tbl_Curhat WHERE Status_Curhat = 'Validasi' ORDER BY Id_Curhat DESC ");

                            foreach ( $session_item AS $data => $item ) :

                                @$data_kasus = queryid (" SELECT Nama_Kasus AS Nama, Eksekusi_Kasus AS Eksekusi FROM Tbl_Kasus WHERE Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                                @$data_jadwal = queryid (" SELECT Id_Jadwal AS Id, JamMulai_Jadwal AS Jam1 FROM Tbl_Jadwal WHERE Id_Jadwal = '". @$item->Id_Jadwal ."' AND Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY JamMulai_Jadwal DESC LIMIT 1 ");

                                if ( @$nomor == '1' ) {

                                    @$__waktu_tiba = substr($data_jadwal->Jam1, 0, 1);
                                    
                                } else {

                                    if ( substr($data_jadwal->Jam1, 0, 1) == '0' ) {

                                        @$__waktu_tiba = substr($data_jadwal->Jam1, 1, 1);

                                    } else {

                                        @$__waktu_tiba = substr($data_jadwal->Jam1, 0, 2);

                                    }

                                }

                                @$__proses_nama = 'P' . @$__proses++;

                                
                                @$__array_sjf[] = [
                                    'Nama_Proses'   => @$__proses_nama,
                                    'Waktu_Tiba'    => @$__waktu_tiba,
                                    'Lama_Eksekusi' => @$data_kasus->Eksekusi,
                                ];
                    
                    ?>

                    <tr>
                        <td>
                            <?= @$nomor++; ?>
                        </td>
                        <td>
                            <?= @$__proses_nama; ?>
                        </td>
                        <td>
                            <?= @$__waktu_tiba; ?>
                        </td>
                        <td>
                            <?= @$data_kasus->Eksekusi; ?>
                        </td>
                    </tr>

                    <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data SJF - Pengurutan
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable1" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Nama Proses</th>
                        <th>Waktu Tiba</th>
                        <th>Lama Eksekusi</th>
                        <th>Giant Chart</th>
                        <th>Waktu Selesai</th>
                    </tr>
                </thead>
                <tbody>

                    <?php

                        @$nomor_1       = '1';

                        function compareByWaktuTiba($a, $b)
                        {
                            return intval($a['Waktu_Tiba']) - intval($b['Waktu_Tiba']);
                            // return intval($b['Waktu_Tiba']) - intval($a['Waktu_Tiba']);
                        }

                        usort($__array_sjf, 'compareByWaktuTiba');

                        @$__minWaktuTiba = min(array_column($__array_sjf, 'Waktu_Tiba'));
                        @$__maxWaktuTiba = max(array_column($__array_sjf, 'Waktu_Tiba'));

                        @$__minLamaEksekusi = min(array_column($__array_sjf, 'Lama_Eksekusi'));
                        @$__maxLamaEksekusi = max(array_column($__array_sjf, 'Lama_Eksekusi'));

                        @$__proses_0 = 'P0';

                    ?>

                    <tr>
                        <td>
                            <?= @$nomor_1; ?>
                        </td>
                        <td>
                            <?= @$__proses_0; ?>
                        </td>
                        <td>

                        </td>
                        <td>

                        </td>
                        <td>
                            <?= @$__minWaktuTiba; ?>
                        </td>
                        <td>
                            <?= @$__minWaktuTiba; ?>
                        </td>
                    </tr>

                    <?php 

                        @$__array_sjf_1 = [];

                        foreach ( $__array_sjf AS $item ) :

                            @$nomor_1_get = @$nomor_1++;

                            @$__giant_chart = @$item['Waktu_Tiba'] + @$item['Lama_Eksekusi'];
                            
                            @$__total_waktuselesai += @$__giant_chart;

                            if ( @$nomor_1_get == '1' ) {

                                @$__waktu_selesai       = @$__minWaktuTiba;
                                @$__waktu_selesai_show  = @$__waktu_selesai + @$__giant_chart;

                            } else {

                                @$__waktu_selesai       = @$__total_waktuselesai;
                                @$__waktu_selesai_show  = @$__waktu_selesai;

                            }


                            @$__array_sjf_1[] = [
                                'Nama_Proses'       => @$item['Nama_Proses'],
                                'Waktu_Tiba'        => @$item['Waktu_Tiba'],
                                'Lama_Eksekusi'     => @$item['Lama_Eksekusi'],
                                'Giant_Chart'       => @$__giant_chart,
                                'Waktu_Selesai'     => @$__waktu_selesai_show,
                            ];
                    
                    ?>

                    <tr>
                        <td>
                            <?= @$nomor_1_get + 1; ?>
                        </td>
                        <td>
                            <?= @$item['Nama_Proses']; ?>
                        </td>
                        <td>
                            <?= @$item['Waktu_Tiba']; ?>
                        </td>
                        <td>
                            <?= @$item['Lama_Eksekusi']; ?>
                        </td>
                        <td>
                            <?= @$__giant_chart; ?>
                        </td>
                        <td>
                            <?= @$__waktu_selesai_show; ?>
                        </td>
                    </tr>

                    <?php endforeach; ?>

                </tbody>
                <tbody>
                    <tr>
                        <th></th>
                        <th>
                            MIN
                        </th>
                        <th>
                            <?= @$__minWaktuTiba; ?>
                        </th>
                        <th>
                            <?= @$__minLamaEksekusi; ?>
                        </th>
                    </tr>
                    <tr>
                        <th></th>
                        <th>
                            MAX
                        </th>
                        <th>
                            <?= @$__maxWaktuTiba; ?>
                        </th>
                        <th>
                            <?= @$__maxLamaEksekusi; ?>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data SJF - Hitung Waitting Time & Turn Arround Time
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable2" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Nama Proses</th>
                        <th>Waktu Tiba</th>
                        <th>Lama Eksekusi</th>
                        <th>Waitting Time</th>
                        <th>Turn Arround Time</th>
                    </tr>
                </thead>
                <tbody>

                    <?php 

                        @$nomor     = '1';

                        function compareNamaProses($a, $b) {
                            return strcmp($a["Nama_Proses"], $b["Nama_Proses"]);
                        }

                        @$jumlah = COUNT( @$__array_sjf_1 );

                        @$__array_sjf_1_awal = @$__array_sjf_1;
                        
                        usort($__array_sjf_1, 'compareNamaProses');

                        for ( $x = 0; $x < $jumlah; $x++ ) :

                            if ( @$__array_sjf_1[$x]['Waktu_Tiba'] == '0' ) {

                                @$__waitting_time = 0 - @$__array_sjf_1_awal[$x]['Waktu_Tiba'];
                    
                            } else {

                                @$__waitting_time = @$__array_sjf_1_awal[$x]['Waktu_Selesai'] - @$__array_sjf_1_awal[$x]['Waktu_Tiba'];

                            }

                            @$total_wt += @$__waitting_time;
                            @$rata_wt   = @$__waitting_time / @$jumlah;

                            
                            @$__turnarround_time = @$__array_sjf_1[$x]['Waktu_Selesai'] - @$__array_sjf_1[$x]['Waktu_Tiba'];
                            
                            @$total_tat += @$__turnarround_time;
                            @$rata_tat   = @$__turnarround_time / @$jumlah;

                    ?>

                    <tr>
                        <td>
                            <?= @$nomor++; ?>
                        </td>
                        <td>
                            <?= @$__array_sjf_1[$x]['Nama_Proses']; ?>
                        </td>
                        <td>
                            <?= @$__array_sjf_1[$x]['Waktu_Tiba']; ?>
                        </td>
                        <td>
                            <?= @$__array_sjf_1[$x]['Lama_Eksekusi']; ?>
                        </td>
                        <td>
                            <?= @$__waitting_time; ?>
                        </td>
                        <td>
                            <?= @$__turnarround_time; ?>
                        </td>
                    </tr>

                    <?php endfor; ?>

                </tbody>
                <tbody>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>
                            Total
                        </th>
                        <th>
                            <?= @$total_wt; ?>
                        </th>
                        <th>
                            <?= @$total_tat; ?>
                        </th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>
                            Rata-Rata
                        </th>
                        <th>
                            <?= number_format( @$rata_wt , 2 ); ?>
                        </th>
                        <th>
                            <?= number_format( @$rata_tat , 2 ); ?>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>