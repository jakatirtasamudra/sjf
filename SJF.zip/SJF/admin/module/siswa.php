<h1 class="h3 mb-2 text-gray-800">
    Setting Data Siswa
</h1>

<?php 

    if ( @$_GET['__Crud'] == 'Hapus' ) { 

        @$__delete_data = [
            'Id'        => @$_GET['__Id'],
        ];

        @$__tabel_siswa = __Tabel_Siswa( 'Hapus', '', @$__delete_data );

        if ( @$__tabel_siswa == '200' ) {

            echo "<script>
                    alert('Berhasil Hapus Data');
                    document.location.href = '?__Module=Siswa';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=Siswa';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Tambah' OR @$_GET['__Crud'] == 'Ubah' ) { 
        
        
        if ( @$_GET['__Id'] == TRUE ) {

            @$session_ubah = queryid (" SELECT IdLogin AS Id, Nama, Username, Password, Level FROM Tbl_Login WHERE IdLogin = '". @$_GET['__Id'] ."' ORDER BY IdLogin DESC LIMIT 1 ");

            if ( @$session_ubah->Id != @$_GET['__Id'] ) {

                echo "<script>
                        alert('ID Ubah Data Tidak Di Temukan');
                        document.location.href = '?__Module=Siswa';
                    </script>";

            }

            @$__keterangan_nama = 'Ubah';
            @$__keterangan_btn  = 'Ubah';

        } else {

            @$__keterangan_nama = 'Tambah';
            @$__keterangan_btn  = 'Simpan';

        }

?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <?= @$__keterangan_nama; ?> Data Siswa
        </h6>
        <br>
        <a href="?__Module=Siswa" class="btn btn-danger shadow">
            Batal
        </a>
    </div>
    <div class="card-body">
        <form class="user" name="frmInput" action="" method="POST" enctype="multipart/form-data">

            <?php if ( @$session_ubah->Id == TRUE ) { ?>
            <input type="hidden" class="form-control" placeholder="Id" name="__Id" autocomplete="off"
                value="<?= @$session_ubah->Id; ?>" required readonly>
            <?php } ?>

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Nama
                        </label>
                        <input type="text" class="form-control" placeholder="Nama" name="__Nama" autocomplete="off"
                            value="<?= @$session_ubah->Nama; ?>" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Username
                        </label>
                        <input type="text" class="form-control" placeholder="Username" name="__Username"
                            autocomplete="off" value="<?= @$session_ubah->Username; ?>" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Password
                        </label>
                        <input type="text" class="form-control" placeholder="Password" name="__Password"
                            autocomplete="off" value="<?= @$session_ubah->Password; ?>" required>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="__BtnSimpan">
                            <?= @$__keterangan_btn; ?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<?php } else { ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data Siswa
        </h6>
        <br>
        <a href="?__Module=Siswa&__Crud=Tambah" class="btn btn-primary shadow">
            Tambah
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Level</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Level</th>
                    </tr>
                </tfoot>
                <tbody>

                    <?php 
                    
                        @$nomor = '1';

                        @$session_item = query (" SELECT IdLogin AS Id, Nama, Username, Password, Level FROM Tbl_Login WHERE Level = 'Siswa' ORDER BY Nama DESC ");

                            foreach ( $session_item AS $data => $item ) :
                    
                    ?>

                    <tr>
                        <td>
                            <?= @$nomor++; ?>
                        </td>
                        <td>
                            <a href="?__Module=Siswa&__Crud=Ubah&__Id=<?= @$item->Id ?>" class="btn btn-success shadow">
                                Ubah
                            </a>
                            <a href="?__Module=Siswa&__Crud=Hapus&__Id=<?= @$item->Id ?>" class="btn btn-danger shadow"
                                onclick="return confirm('Apakah Anda Yakin Untuk Hapus Data Ini ?')">
                                Hapus
                            </a>
                        </td>
                        <td>
                            <?= @$item->Nama; ?>
                        </td>
                        <td>
                            <?= @$item->Username; ?>
                        </td>
                        <td>
                            <?= @$item->Password; ?>
                        </td>
                        <td>
                            <?= @$item->Level; ?>
                        </td>
                    </tr>

                    <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php 

    }
    

        if ( isset( $_POST['__BtnSimpan'] ) ) {

            if ( @$_POST['__Nama'] == TRUE AND @$_POST['__Username'] == TRUE AND @$_POST['__Password'] == TRUE ) {

                if ( @$_POST['__Id'] == TRUE ) {

                    @$session_cek = queryid (" SELECT IdLogin AS Id FROM Tbl_Login WHERE Username = '". @$_POST['__Username'] ."' AND Level = 'Siswa' AND NOT IdLogin = '". @$_POST['__Id'] ."' ORDER BY IdLogin DESC LIMIT 1 ");

                    if ( @$session_cek->Id == TRUE ) {

                        echo "<script>
                                alert('Username Sudah Terdaftar, Harap Pakai Username Lainnya');
                                document.location.href = '?__Module=Siswa&__Crud=Ubah&__Id=". @$_POST['__Id'] ."';
                            </script>";

                    } else {

                        @$__update_data = [
                            'Username'  => @$_POST['__Username'],
                            'Password'  => @$_POST['__Password'],
                            'Nama'      => @$_POST['__Nama'],
                            'Id'        => @$_POST['__Id'],
                        ];

                        @$__tabel_siswa = __Tabel_Siswa( 'Ubah', '', @$__update_data );

                        if ( @$__tabel_siswa == '200' ) {

                            echo "<script>
                                    alert('Berhasil Ubah Data');
                                    document.location.href = '?__Module=Siswa';
                                </script>";

                        } else {

                            echo "<script>
                                    alert('Query Error');
                                    document.location.href = '?__Module=Siswa&__Crud=Ubah&__Id=". @$_POST['__Id'] ."';
                                </script>";

                        }

                    }

                } else {

                    @$session_cek = queryid (" SELECT IdLogin AS Id FROM Tbl_Login WHERE Username = '". @$_POST['__Username'] ."' AND Level = 'Siswa' ORDER BY IdLogin DESC LIMIT 1 ");

                    if ( @$session_cek->Id == TRUE ) {

                        echo "<script>
                                alert('Username Sudah Terdaftar, Harap Pakai Username Lainnya');
                                document.location.href = '?__Module=Siswa&__Crud=Tambah';
                            </script>";

                    } else {

                        @$__insert_data = [
                            'Username'  => @$_POST['__Username'],
                            'Password'  => @$_POST['__Password'],
                            'Nama'      => @$_POST['__Nama'],
                            'Level'     => 'Siswa',
                        ];

                        @$__tabel_siswa = __Tabel_Siswa( 'Tambah', '', @$__insert_data );

                        if ( @$__tabel_siswa == '200' ) {

                            echo "<script>
                                    alert('Berhasil Simpan Data');
                                    document.location.href = '?__Module=Siswa';
                                </script>";

                        } else {

                            echo "<script>
                                    alert('Query Error');
                                    document.location.href = '?__Module=Siswa&__Crud=Tambah';
                                </script>";

                        }

                    }

                }

            } else {

                echo "<script>
                        alert('Isi Form Dengan Benar');
                        document.location.href = '?__Module=Siswa&__Crud=Tambah';
                    </script>";

            }

        }
    
    
?>