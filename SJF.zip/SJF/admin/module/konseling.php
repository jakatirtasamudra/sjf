<?php

    @$session_curhat = queryid (" SELECT Id_Curhat AS Id, Id_Jadwal, Id_Kasus, Id_Siswa, Id_Guru FROM Tbl_Curhat WHERE Id_Curhat = '". @$_GET['__Id'] ."' AND Status_Curhat = 'Validasi' ORDER BY Id_Curhat DESC LIMIT 1 ");

        if ( @$session_user->Level == 'Siswa' ) {

            @$__page            = 'LihatJadwal';
            @$__pengirim_siswa  = @$session_curhat->Id_Siswa;

        } elseif ( @$session_user->Level == 'Guru' ) {

            @$__page            = 'JadwalBimbingan';
            @$__pengirim_guru   = @$session_curhat->Id_Guru;

        }

?>


<h1 class="h3 mb-2 text-gray-800">
    Konseling
</h1>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Media Konseling
        </h6>
        <br>
        <a href="?__Module=<?= @$__page; ?>" class="btn btn-danger shadow">
            Kembali
        </a>
    </div>
    <div class="card-body">
        <form class="user" name="frmInput" action="" method="POST" enctype="multipart/form-data">

            <input type="hidden" class="form-control" placeholder="Id" name="__Id" autocomplete="off"
                value="<?= @$session_curhat->Id; ?>" required readonly>

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Pesan
                        </label>
                        <input type="text" class="form-control" placeholder="Pesan" name="__Pesan" autocomplete="off"
                            value="" required>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="__BtnSimpan">
                            Kirim
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="row">
            <?php 
            
                @$session_konseling = query (" SELECT Id_Konseling AS Id, Pesan, Tanggal, Id_Siswa, Id_Guru, Id_Curhat FROM Tbl_Konseling WHERE Id_Curhat = '". @$session_curhat->Id ."' ORDER BY Tanggal DESC ");

                    foreach ( $session_konseling AS $data => $konseling ) :

                        if ( @$konseling->Id_Siswa == TRUE ) {

                            @$__nama = queryid (" SELECT Nama FROM Tbl_Login WHERE IdLogin = '". @$konseling->Id_Siswa ."' ORDER BY IdLogin DESC LIMIT 1 ");

                        } elseif ( @$konseling->Id_Guru == TRUE ) {

                            @$__nama = queryid (" SELECT Nama FROM Tbl_Login WHERE IdLogin = '". @$konseling->Id_Guru ."' ORDER BY IdLogin DESC LIMIT 1 ");

                        }

                        if ( @$session_user->Id == @$konseling->Id_Siswa OR @$session_user->Id == @$konseling->Id_Guru ) {

                            echo 
                                "
                                    <div class='col-lg-12 col-md-12 col-sm-12 text-right'>
                                        <h4 class='text-success'>
                                            ". @$konseling->Pesan ."
                                        </h4>
                                        <small>
                                            ". @$konseling->Tanggal ."
                                            <br>
                                            ". @$__nama->Nama ."
                                        </small>
                                        <hr>
                                    </div>
                                ";

                        } else {

                            echo 
                                "
                                    <div class='col-lg-12 col-md-12 col-sm-12 text-left'>
                                        <h4 class='text-primary'>
                                            ". @$konseling->Pesan ."
                                        </h4>
                                        <small>
                                            ". @$konseling->Tanggal ."
                                            <br>
                                            ". @$__nama->Nama ."
                                        </small>
                                        <hr>
                                    </div>
                                ";

                        }

                    endforeach;
            
            ?>
        </div>
    </div>
</div>



<?php 

    if ( isset( $_POST['__BtnSimpan'] ) ) {

        if ( @$_POST['__Pesan'] == TRUE ) {

            @$__insert_data = [
                'Pesan'         => @$_POST['__Pesan'],
                'Tanggal'       => date('Y-m-d H:i:s'),
                'Id_Siswa'      => @$__pengirim_siswa,
                'Id_Guru'       => @$__pengirim_guru,
                'Id_Curhat'     => @$session_curhat->Id,
            ];

            @$__tabel_konseling = __Tabel_Konseling( 'Tambah', '', @$__insert_data );

            if ( @$__tabel_konseling == '200' ) {

                echo "<script>
                        document.location.href = '?__Module=Konseling&__Id=". @$_GET['__Id'] ."';
                    </script>";

            } else {

                echo "<script>
                        alert('Query Error');
                        document.location.href = '?__Module=Konseling&__Id=". @$_GET['__Id'] ."';
                    </script>";

            }

        } else {

            echo "<script>
                    alert('Isi Form Dengan Benar');
                    document.location.href = '?__Module=Konseling&__Id=". @$_GET['__Id'] ."';
                </script>";

        }

    }