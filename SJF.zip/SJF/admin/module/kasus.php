<h1 class="h3 mb-2 text-gray-800">
    Setting Data Kasus
</h1>

<?php 

    if ( @$_GET['__Crud'] == 'Hapus' ) { 

        @$__delete_data = [
            'Id'        => @$_GET['__Id'],
        ];

        @$__tabel_kasus = __Tabel_Kasus( 'Hapus', '', @$__delete_data );

        if ( @$__tabel_kasus == '200' ) {

            echo "<script>
                    alert('Berhasil Hapus Data');
                    document.location.href = '?__Module=Kasus';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=Kasus';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Tambah' OR @$_GET['__Crud'] == 'Ubah' ) { 
        
        
        if ( @$_GET['__Id'] == TRUE ) {

            @$session_ubah = queryid (" SELECT Id_Kasus AS Id, Kode_Kasus AS Kode, Nama_Kasus AS Nama, Eksekusi_Kasus AS Eksekusi FROM Tbl_Kasus WHERE Id_Kasus = '". @$_GET['__Id'] ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

            if ( @$session_ubah->Id != @$_GET['__Id'] ) {

                echo "<script>
                        alert('ID Ubah Data Tidak Di Temukan');
                        document.location.href = '?__Module=Kasus';
                    </script>";

            }

            @$__keterangan_nama = 'Ubah';
            @$__keterangan_btn  = 'Ubah';

        } else {

            @$__keterangan_nama = 'Tambah';
            @$__keterangan_btn  = 'Simpan';

        }

?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <?= @$__keterangan_nama; ?> Data Kasus
        </h6>
        <br>
        <a href="?__Module=Kasus" class="btn btn-danger shadow">
            Batal
        </a>
    </div>
    <div class="card-body">
        <form class="user" name="frmInput" action="" method="POST" enctype="multipart/form-data">

            <?php if ( @$session_ubah->Id == TRUE ) { ?>
            <input type="hidden" class="form-control" placeholder="Id" name="__Id" autocomplete="off"
                value="<?= @$session_ubah->Id; ?>" required readonly>
            <?php } ?>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Kode
                        </label>
                        <input type="text" class="form-control" placeholder="Kode" name="__Kode" autocomplete="off"
                            value="<?= @$session_ubah->Kode; ?>" maxlength="4" style="text-transform:uppercase"
                            required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Nama
                        </label>
                        <input type="text" class="form-control" placeholder="Nama" name="__Nama" autocomplete="off"
                            value="<?= @$session_ubah->Nama; ?>" required>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Eksekusi
                        </label>
                        <input type="number" class="form-control" placeholder="Eksekusi" name="__Eksekusi"
                            autocomplete="off" value="<?= @$session_ubah->Eksekusi; ?>" required>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="__BtnSimpan">
                            <?= @$__keterangan_btn; ?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<?php } else { ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data Kasus
        </h6>
        <br>
        <a href="?__Module=Kasus&__Crud=Tambah" class="btn btn-primary shadow">
            Tambah
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Kode Kasus</th>
                        <th>Nama Kasus</th>
                        <th>Lama Eksekusi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Kode Kasus</th>
                        <th>Nama Kasus</th>
                        <th>Lama Eksekusi</th>
                    </tr>
                </tfoot>
                <tbody>

                    <?php 
                    
                        @$nomor = '1';

                        @$session_item = query (" SELECT Id_Kasus AS Id, Kode_Kasus AS Kode, Nama_Kasus AS Nama, Eksekusi_Kasus AS Eksekusi FROM Tbl_Kasus ORDER BY Kode_Kasus DESC ");

                            foreach ( $session_item AS $data => $item ) :
                    
                    ?>

                    <tr>
                        <td>
                            <?= @$nomor++; ?>
                        </td>
                        <td>
                            <a href="?__Module=Kasus&__Crud=Ubah&__Id=<?= @$item->Id ?>" class="btn btn-success shadow">
                                Ubah
                            </a>
                            <a href="?__Module=Kasus&__Crud=Hapus&__Id=<?= @$item->Id ?>" class="btn btn-danger shadow"
                                onclick="return confirm('Apakah Anda Yakin Untuk Hapus Data Ini ?')">
                                Hapus
                            </a>
                        </td>
                        <td>
                            <?= @$item->Kode; ?>
                        </td>
                        <td>
                            <?= @$item->Nama; ?>
                        </td>
                        <td>
                            <?= @$item->Eksekusi; ?>
                        </td>
                    </tr>

                    <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php 

    }
    

        if ( isset( $_POST['__BtnSimpan'] ) ) {

            if ( @$_POST['__Kode'] == TRUE AND @$_POST['__Nama'] == TRUE AND @$_POST['__Eksekusi'] == TRUE ) {

                if ( @$_POST['__Id'] == TRUE ) {

                    @$session_cek = queryid (" SELECT Id_Kasus AS Id FROM Tbl_Kasus WHERE Kode_Kasus = '". @$_POST['__Kode'] ."' AND NOT Id_Kasus = '". @$_POST['__Id'] ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                    if ( @$session_cek->Id == TRUE ) {

                        echo "<script>
                                alert('Kode Sudah Terdaftar, Harap Pakai Kode Lainnya');
                                document.location.href = '?__Module=Kasus&__Crud=Ubah&__Id=". @$_POST['__Id'] ."';
                            </script>";

                    } else {

                        @$__update_data = [
                            'Kode'      => strtoupper( @$_POST['__Kode'] ),
                            'Nama'      => strtoupper( @$_POST['__Nama'] ),
                            'Eksekusi'  => strtoupper( @$_POST['__Eksekusi'] ),
                            'Id'        => @$_POST['__Id'],
                        ];

                        @$__tabel_kasus = __Tabel_Kasus( 'Ubah', '', @$__update_data );

                        if ( @$__tabel_kasus == '200' ) {

                            echo "<script>
                                    alert('Berhasil Ubah Data');
                                    document.location.href = '?__Module=Kasus';
                                </script>";

                        } else {

                            echo "<script>
                                    alert('Query Error');
                                    document.location.href = '?__Module=Kasus&__Crud=Ubah&__Id=". @$_POST['__Id'] ."';
                                </script>";

                        }

                    }

                } else {

                    @$session_cek = queryid (" SELECT Id_Kasus AS Id FROM Tbl_Kasus WHERE Kode_Kasus = '". @$_POST['__Kode'] ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                    if ( @$session_cek->Id == TRUE ) {

                        echo "<script>
                                alert('Kode Sudah Terdaftar, Harap Pakai Kode Lainnya');
                                document.location.href = '?__Module=Kasus&__Crud=Tambah';
                            </script>";

                    } else {

                        @$__insert_data = [
                            'Kode'      => strtoupper( @$_POST['__Kode'] ),
                            'Nama'      => strtoupper( @$_POST['__Nama'] ),
                            'Eksekusi'  => strtoupper( @$_POST['__Eksekusi'] ),
                        ];

                        @$__tabel_kasus = __Tabel_Kasus( 'Tambah', '', @$__insert_data );

                        if ( @$__tabel_kasus == '200' ) {

                            echo "<script>
                                    alert('Berhasil Simpan Data');
                                    document.location.href = '?__Module=Kasus';
                                </script>";

                        } else {

                            echo "<script>
                                    alert('Query Error');
                                    document.location.href = '?__Module=Kasus&__Crud=Tambah';
                                </script>";

                        }

                    }

                }

            } else {

                echo "<script>
                        alert('Isi Form Dengan Benar');
                        document.location.href = '?__Module=Kasus&__Crud=Tambah';
                    </script>";

            }

        }
    
    
?>