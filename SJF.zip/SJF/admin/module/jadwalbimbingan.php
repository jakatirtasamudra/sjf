<h1 class="h3 mb-2 text-gray-800">
    Setting Data Jadwal Bimbingan
</h1>

<?php 

    if ( @$_GET['__Crud'] == 'Tolak' ) { 

        @$__tolak_data = [
            'Status'    => 'Tolak',
            'Id'        => @$_GET['__IdCurhat'],
            'Id_Jadwal' => @$_GET['__Id'],
        ];

        @$__tabel_curhat = __Tabel_Curhat( 'Tolak', '', @$__tolak_data );

        if ( @$__tabel_curhat == '200' ) {

            echo "<script>
                    alert('Berhasil Tolak Data');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Validasi' ) { 

        @$__validasi_data = [
            'Status'    => 'Validasi',
            'Id'        => @$_GET['__IdCurhat'],
            'Id_Jadwal' => @$_GET['__Id'],
        ];

        @$__tabel_curhat = __Tabel_Curhat( 'Validasi', '', @$__validasi_data );

        if ( @$__tabel_curhat == '200' ) {

            echo "<script>
                    alert('Berhasil Validasi Data');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Hapus' ) { 

        @$__delete_data = [
            'Id'        => @$_GET['__Id'],
        ];

        @$__tabel_jadwal = __Tabel_Jadwal( 'Hapus', '', @$__delete_data );

        if ( @$__tabel_jadwal == '200' ) {

            echo "<script>
                    alert('Berhasil Hapus Data');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Aktif' ) { 

        @$__update_data = [
            'Id'        => @$_GET['__Id'],
        ];

        @$__tabel_jadwal = __Tabel_Jadwal( 'Aktif', '', @$__update_data );

        if ( @$__tabel_jadwal == '200' ) {

            echo "<script>
                    alert('Berhasil Aktif Data');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Tidak Aktif' ) { 

        @$__update_data = [
            'Id'        => @$_GET['__Id'],
        ];

        @$__tabel_jadwal = __Tabel_Jadwal( 'Tidak Aktif', '', @$__update_data );

        if ( @$__tabel_jadwal == '200' ) {

            echo "<script>
                    alert('Berhasil Tidak Aktif Data');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=JadwalBimbingan';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Tambah' OR @$_GET['__Crud'] == 'Ubah' ) { 
        
        
        if ( @$_GET['__Id'] == TRUE ) {

            @$session_ubah = queryid (" SELECT Id_Jadwal AS Id, Id_Kasus, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2, Status_Jadwal AS Status FROM Tbl_Jadwal WHERE Id_Jadwal = '". @$_GET['__Id'] ."' ORDER BY Id_Jadwal DESC LIMIT 1 ");

            if ( @$session_ubah->Id != @$_GET['__Id'] ) {

                echo "<script>
                        alert('ID Ubah Data Tidak Di Temukan');
                        document.location.href = '?__Module=JadwalBimbingan';
                    </script>";

            }

            @$__keterangan_nama = 'Ubah';
            @$__keterangan_btn  = 'Ubah';

        } else {

            @$__keterangan_nama = 'Tambah';
            @$__keterangan_btn  = 'Simpan';

            @$session_tambah = queryid (" SELECT MAX( Id_Jadwal ) AS Id, MAX( Tgl_Jadwal ) AS Tgl, MAX( JamMulai_Jadwal ) AS Jam1, MAX( JamSelesai_Jadwal ) AS Jam2 FROM Tbl_Jadwal ORDER BY Id_Jadwal DESC LIMIT 1 ");

            if ( @$session_tambah->Id == TRUE ) {

                if ( date('Y-m-d') == date('Y-m-d', strtotime( @$session_tambah->Tgl )) ) {

                    @$__tanggal_tambah  = date('Y-m-d', strtotime( @$session_tambah->Tgl ));
                    @$__jam1_tambah     = date('H:i', strtotime('+2 hours', strtotime( @$session_tambah->Jam1 )));
                    @$__jam2_tambah     = date('H:i', strtotime('+2 hours', strtotime( @$session_tambah->Jam2 )));

                } else {

                    @$__tanggal_tambah  = date('Y-m-d');
                    @$__jam1_tambah     = date('H:i', strtotime('+2 hours', strtotime( @$session_tambah->Jam1 )));
                    @$__jam2_tambah     = date('H:i', strtotime('+2 hours', strtotime( @$session_tambah->Jam2 )));

                }
                
            } else {

                @$__tanggal_tambah  = date('Y-m-d');
                @$__jam1_tambah     = date('H') . ':00';
                @$__jam2_tambah     = date('H', strtotime('+2 hours', strtotime( @$__jam1_tambah ))) . ':00';

            }

        }

?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <?= @$__keterangan_nama; ?> Data Jadwal Bimbingan
        </h6>
        <br>
        <a href="?__Module=JadwalBimbingan" class="btn btn-danger shadow">
            Batal
        </a>
    </div>
    <div class="card-body">
        <form class="user" name="frmInput" action="" method="POST" enctype="multipart/form-data">

            <?php if ( @$session_ubah->Id == TRUE ) { ?>
            <input type="hidden" class="form-control" placeholder="Id" name="__Id" autocomplete="off"
                value="<?= @$session_ubah->Id; ?>" required readonly>
            <?php } ?>

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Nama Kasus
                        </label>
                        <select name="__IdKasus" class="form-control" required>
                            <?php 

                                if ( @$session_ubah->Id == TRUE ) {

                                    @$session_kasus_get = queryid (" SELECT Id_Kasus AS Id, Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$session_ubah->Id_Kasus ."' ORDER BY Nama_Kasus DESC ");

                                    echo 
                                        "
                                            <option value='". @$session_kasus_get->Id ."' selected>
                                                ". strtoupper( @$session_kasus_get->Nama ) ."
                                            </option>
                                            <option value='' disabled>
                                                --- ##### ---
                                            </option>
                                        ";

                                } else {

                                    echo 
                                        "
                                            <option value='' disabled>
                                                --- Pilih Kasus Curhatan ---
                                            </option>
                                        ";

                                }

                                    @$session_kasus = query (" SELECT Id_Kasus AS Id, Nama_Kasus AS Nama FROM Tbl_Kasus ORDER BY Nama_Kasus DESC ");

                                        foreach ( $session_kasus AS $data => $kasus ) :

                                            if ( @$session_ubah->Id_Kasus != @$kasus->Id ) {

                                                echo 
                                                    "
                                                        <option value='". @$kasus->Id ."'>
                                                            ". strtoupper( @$kasus->Nama ) ."
                                                        </option>
                                                    ";

                                            }

                                        endforeach;
                            
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Tanggal
                        </label>
                        <input type="date" class="form-control" placeholder="Tanggal" name="__Tanggal"
                            autocomplete="off"
                            value="<?php if ( @$session_ubah->Id == TRUE ) { echo date('Y-m-d', strtotime( @$session_ubah->Tgl )); } else { echo @$__tanggal_tambah; } ?>"
                            required readonly>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Jam Mulai
                        </label>
                        <input type="text" class="form-control" placeholder="Jam Mulai" name="__JamMulai"
                            autocomplete="off"
                            value="<?php if ( @$session_ubah->Id == TRUE ) { echo date('H:i', strtotime( @$session_ubah->Jam1 )); } else { echo @$__jam1_tambah; } ?>"
                            required readonly>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Jam Selesai
                        </label>
                        <input type="text" class="form-control" placeholder="Jam Selesai" name="__JamSelesai"
                            autocomplete="off"
                            value="<?php if ( @$session_ubah->Id == TRUE ) { echo date('H:i', strtotime( @$session_ubah->Jam2 )); } else { echo @$__jam2_tambah; } ?>"
                            required readonly>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="__BtnSimpan">
                            <?= @$__keterangan_btn; ?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<?php } else { ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data Jadwal Bimbingan
        </h6>
        <br>
        <a href="?__Module=JadwalBimbingan&__Crud=Tambah" class="btn btn-primary shadow">
            Tambah
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Konseling</th>
                        <th>Nama Kasus</th>
                        <th>Tanggal</th>
                        <th>Jam Curhat</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Konseling</th>
                        <th>Nama Kasus</th>
                        <th>Tanggal</th>
                        <th>Jam Curhat</th>
                        <th>Status</th>
                    </tr>
                </tfoot>
                <tbody>

                    <?php 
                    
                        @$nomor = '1';

                        @$session_item = query (" SELECT Id_Jadwal AS Id, Id_Kasus, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2, Status_Jadwal AS Status FROM Tbl_Jadwal ORDER BY JamMulai_Jadwal DESC ");

                            foreach ( $session_item AS $data => $item ) :

                                @$data_kasus = queryid (" SELECT Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                                @$data_curhat = queryid (" SELECT Id_Curhat AS Id, Id_Jadwal, Id_Guru, Status_Curhat AS Status FROM Tbl_Curhat WHERE Id_Jadwal = '". @$item->Id ."' ORDER BY Id_Curhat DESC LIMIT 1 ");

                                    if ( @$data_curhat->Id_Jadwal == @$item->Id ) {

                                        @$data_guru = queryid (" SELECT IdLogin AS Id, Nama FROM Tbl_Login WHERE IdLogin = '".  @$data_curhat->Id_Guru ."' AND Level = 'Guru' ORDER BY IdLogin DESC LIMIT 1 ");

                                    }
                    
                    ?>

                    <tr>
                        <td>
                            <?= @$nomor++; ?>
                        </td>
                        <td>
                            <?php if ( @$data_curhat->Id_Jadwal == @$item->Id ) { ?>
                            <div>
                                <?php if ( @$data_guru->Id == @$session_user->Id ) { ?>
                                <div>
                                    <?php if ( @$data_curhat->Status == 'Menunggu' ) { ?>
                                    <a href="?__Module=JadwalBimbingan&__Crud=Tolak&__Id=<?= @$item->Id; ?>&__IdCurhat=<?= @$data_curhat->Id; ?>"
                                        class="btn btn-outline-warning shadow"
                                        onclick="return confirm('Apakah Anda Yakin Untuk Tolak Data Ini ?')">
                                        Tolak
                                    </a>
                                    <a href="?__Module=JadwalBimbingan&__Crud=Validasi&__Id=<?= @$item->Id; ?>&__IdCurhat=<?= @$data_curhat->Id; ?>"
                                        class="btn btn-outline-primary shadow"
                                        onclick="return confirm('Apakah Anda Yakin Untuk Validasi Data Ini ?')">
                                        Validasi
                                    </a>
                                    <?php } elseif ( @$data_curhat->Status == 'Validasi' ) { ?>
                                    <span class="badge badge-success">
                                        Validasi
                                    </span>
                                    <?php } elseif ( @$data_curhat->Status == 'Tolak' ) { ?>
                                    <span class="badge badge-danger">
                                        Tolak
                                    </span>
                                    <?php } else { ?>
                                    <span class="badge badge-warning">
                                        Tidak Ada Kondisi
                                    </span>
                                    <?php } ?>
                                </div>
                                <?php } else { ?>
                                <span class="badge bg-danger text-white">
                                    Kunci
                                </span>
                                <?php } ?>
                            </div>
                            <?php } else { ?>
                            <a href="?__Module=JadwalBimbingan&__Crud=Ubah&__Id=<?= @$item->Id ?>"
                                class="btn btn-success shadow">
                                Ubah
                            </a>
                            <a href="?__Module=JadwalBimbingan&__Crud=Hapus&__Id=<?= @$item->Id ?>"
                                class="btn btn-danger shadow"
                                onclick="return confirm('Apakah Anda Yakin Untuk Hapus Data Ini ?')">
                                Hapus
                            </a>
                            <?php if ( @$item->Status == 'Tidak Aktif' ) { ?>
                            <a href="?__Module=JadwalBimbingan&__Crud=Aktif&__Id=<?= @$item->Id ?>"
                                class="btn btn-primary shadow"
                                onclick="return confirm('Apakah Anda Yakin Untuk Aktif Data Ini, Jika Sudah Di Aktifkan Maka Tidak Bisa Di Non-Aktifkan Kembali ?')">
                                Aktif
                            </a>
                            <?php } ?>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ( @$data_curhat->Status == 'Validasi' AND @$data_guru->Id == @$session_user->Id ) { ?>
                            <div>
                                <a href="?__Module=Konseling&__Id=<?= @$data_curhat->Id ?>"
                                    class="btn btn-primary shadow">
                                    Konseling
                                </a>
                            </div>
                            <?php } else { ?>
                            <div>
                                <span class="badge bg-danger text-white">
                                    Kunci
                                </span>
                            </div>
                            <?php } ?>
                        </td>
                        <td>
                            <?= @$data_kasus->Nama; ?>
                        </td>
                        <td>
                            <?= date('d M Y', strtotime( @$item->Tgl )); ?>
                        </td>
                        <td>
                            <?= date('H:i', strtotime( @$item->Jam1 )); ?>
                            <br>
                            s/d
                            <br>
                            <?= date('H:i', strtotime( @$item->Jam2 )); ?>
                        </td>
                        <td>
                            <?php
                            
                                if ( @$item->Status == 'Aktif' ) {

                                    echo 
                                        "
                                            <span class='badge-primary'>
                                                Aktif
                                            </span>
                                        ";

                                } else {

                                    echo 
                                        "
                                            <span class='badge-danger'>
                                                Tidak Aktif
                                            </span>
                                        ";

                                }
                            
                            ?>
                        </td>
                    </tr>

                    <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php 

    }
    

        if ( isset( $_POST['__BtnSimpan'] ) ) {

            if ( @$_POST['__IdKasus'] == TRUE AND @$_POST['__Tanggal'] == TRUE AND @$_POST['__JamMulai'] == TRUE AND @$_POST['__JamSelesai'] == TRUE ) {

                if ( @$_POST['__Id'] == TRUE ) {

                    @$__update_data = [
                        'Id_Kasus'  => @$_POST['__IdKasus'],
                        'Id'        => @$_POST['__Id'],
                    ];

                    @$__tabel_jadwal = __Tabel_Jadwal( 'Ubah', '', @$__update_data );

                    if ( @$__tabel_jadwal == '200' ) {

                        echo "<script>
                                alert('Berhasil Ubah Data');
                                document.location.href = '?__Module=JadwalBimbingan';
                            </script>";

                    } else {

                        echo "<script>
                                alert('Query Error');
                                document.location.href = '?__Module=JadwalBimbingan&__Crud=Ubah&__Id=". @$_POST['__Id'] ."';
                            </script>";

                    }

                } else {

                    if ( date('Y-m-d') > @$_POST['__Tanggal'] ) {

                        echo "<script>
                                alert('Tanggal Jadwal Tidak Boleh Mundur Dari Tanggal Saat Ini');
                                document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                            </script>";

                    } else {

                        // if ( date('H:i') > @$_POST['__JamMulai'] ) {

                        //     echo "<script>
                        //             alert('Jam Jadwal Tidak Boleh Mundur Dari Jam Saat Ini');
                        //             document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                        //         </script>";

                        // } else {

                            if ( @$_POST['__JamMulai'] == @$_POST['__JamSelesai'] ) {

                                echo "<script>
                                        alert('Jam Mulai dan Jam Selesai Tidak Boleh Sama');
                                        document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                                    </script>";

                            } else {

                                if ( @$_POST['__JamMulai'] > @$_POST['__JamSelesai'] ) {

                                    echo "<script>
                                            alert('Jam Mulai Tidak Boleh Maju Dari Jam Selesai');
                                            document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                                        </script>";

                                } else {

                                    @$session_cek = queryid (" SELECT Id_Jadwal AS Id FROM Tbl_Jadwal WHERE Tgl_Jadwal = '". @$_POST['__Tanggal'] ."' AND JamSelesai_Jadwal > '". @$_POST['__JamSelesai'] ."' ORDER BY Id_Jadwal DESC LIMIT 1 ");

                                    if ( @$session_cek->Id == TRUE ) {

                                        echo "<script>
                                                alert('Mohon Maaf Jadwal Sudah Ada Di Antara Jam ". @$_POST['__JamMulai'] ." s/d ". @$_POST['__JamSelesai'] ."');
                                                document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                                            </script>";

                                    } else {

                                        @$__insert_data = [
                                            'Id_Kasus'      => @$_POST['__IdKasus'],
                                            'Tanggal'       => @$_POST['__Tanggal'],
                                            'Jam_Mulai'     => @$_POST['__JamMulai'],
                                            'Jam_Selesai'   => @$_POST['__JamSelesai'],
                                            'Status'        => 'Tidak Aktif',
                                        ];

                                        @$__tabel_jadwal = __Tabel_Jadwal( 'Tambah', '', @$__insert_data );

                                        if ( @$__tabel_jadwal == '200' ) {

                                            echo "<script>
                                                    alert('Berhasil Simpan Data');
                                                    document.location.href = '?__Module=JadwalBimbingan';
                                                </script>";

                                        } else {

                                            echo "<script>
                                                    alert('Query Error');
                                                    document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                                                </script>";

                                        }

                                    }

                                }

                            }

                        // }

                    }

                }

            } else {

                echo "<script>
                        alert('Isi Form Dengan Benar');
                        document.location.href = '?__Module=JadwalBimbingan&__Crud=Tambah';
                    </script>";

            }

        }
    
    
?>