<h1 class="h3 mb-2 text-gray-800">
    Lihat Data Jadwal
</h1>

<?php 

    if ( @$_GET['__Crud'] == 'Hapus' ) { 

        @$__delete_data = [
            'Id'        => @$_GET['__IdCurhat'],
            'Id_Jadwal' => @$_GET['__Id'],
        ];

        @$__tabel_curhat = __Tabel_Curhat( 'Hapus', '', @$__delete_data );

        if ( @$__tabel_curhat == '200' ) {

            echo "<script>
                    alert('Berhasil Hapus Data');
                    document.location.href = '?__Module=LihatJadwal';
                </script>";

        } else {

            echo "<script>
                    alert('Query Error');
                    document.location.href = '?__Module=LihatJadwal';
                </script>";

        }

    } elseif ( @$_GET['__Crud'] == 'Tambah' ) { 
        
        
        if ( @$_GET['__Id'] == TRUE ) {

            @$session_tambah = queryid (" SELECT Id_Jadwal AS Id, Id_Kasus, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2, Status_Jadwal AS Status FROM Tbl_Jadwal WHERE Id_Jadwal = '". @$_GET['__Id'] ."' ORDER BY Id_Jadwal DESC LIMIT 1 ");

            @$session_kasus = queryid (" SELECT Id_Kasus AS Id, Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$session_tambah->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

            if ( @$session_tambah->Id != @$_GET['__Id'] AND @$session_kasus->Id != @$session_tambah->Id_Kasus ) {

                echo "<script>
                        alert('ID Tambah Data Tidak Di Temukan');
                        document.location.href = '?__Module=LihatJadwal';
                    </script>";

            }

            @$__keterangan_nama = 'Tambah';
            @$__keterangan_btn  = 'Simpan';

        } else {

            echo "<script>
                    alert('ID Jadwal Data Tidak Di Temukan');
                    document.location.href = '?__Module=LihatJadwal';
                </script>";

        }

?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <?= @$__keterangan_nama; ?> Data Jadwal
        </h6>
        <br>
        <a href="?__Module=LihatJadwal" class="btn btn-danger shadow">
            Batal
        </a>
    </div>
    <div class="card-body">
        <form class="user" name="frmInput" action="" method="POST" enctype="multipart/form-data">

            <?php if ( @$session_tambah->Id == TRUE ) { ?>
            <input type="hidden" class="form-control" placeholder="Id" name="__IdJadwal" autocomplete="off"
                value="<?= @$session_tambah->Id; ?>" required readonly>

            <input type="hidden" class="form-control" placeholder="Id" name="__IdKasus" autocomplete="off"
                value="<?= @$session_kasus->Id; ?>" required readonly>
            <?php } ?>

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Pilih Guru
                        </label>
                        <select name="__IdGuru" class="form-control" required>
                            <?php 

                                echo 
                                    "
                                        <option value='' disabled>
                                            --- Pilih Guru ---
                                        </option>
                                    ";

                                @$session_guru = query (" SELECT IdLogin AS Id, Nama FROM Tbl_Login WHERE Level = 'Guru' ORDER BY Nama DESC ");

                                    foreach ( $session_guru AS $data => $guru ) :

                                        echo 
                                            "
                                                <option value='". @$guru->Id ."'>
                                                    ". strtoupper( @$guru->Nama ) ."
                                                </option>
                                            ";

                                    endforeach;
                            
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Nama Kasus
                        </label>
                        <input type="text" class="form-control" placeholder="Nama Kasus" autocomplete="off"
                            value="<?= strtoupper( @$session_kasus->Nama ); ?>" required readonly>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <label>
                            Tanggal
                        </label>
                        <input type="date" class="form-control" placeholder="Tanggal" autocomplete="off"
                            value="<?= date('Y-m-d', strtotime( @$session_tambah->Tgl )) ?>" required readonly>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Jam Mulai
                        </label>
                        <input type="text" class="form-control" placeholder="Jam Mulai" autocomplete="off"
                            value="<?= date('H:i', strtotime( @$session_tambah->Jam1 )); ?>" required readonly>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label>
                            Jam Selesai
                        </label>
                        <input type="text" class="form-control" placeholder="Jam Selesai" autocomplete="off"
                            value="<?= date('H:i', strtotime( @$session_tambah->Jam2 )); ?>" required readonly>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="__BtnSimpan">
                            <?= @$__keterangan_btn; ?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<?php } else { ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Data Jadwal Bimbingan
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Konseling</th>
                        <th>Nama Kasus</th>
                        <th>Tanggal</th>
                        <th>Jam Curhat</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Nomor</th>
                        <th>Aksi</th>
                        <th>Konseling</th>
                        <th>Nama Kasus</th>
                        <th>Tanggal</th>
                        <th>Jam Curhat</th>
                    </tr>
                </tfoot>
                <tbody>

                    <?php 
                    
                        @$nomor = '1';

                        @$session_item = query (" SELECT Id_Jadwal AS Id, Id_Kasus, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2, Status_Jadwal AS Status FROM Tbl_Jadwal WHERE Status_Jadwal = 'Aktif' ORDER BY JamMulai_Jadwal DESC ");

                            foreach ( $session_item AS $data => $item ) :

                                @$data_kasus = queryid (" SELECT Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                                @$data_curhat = queryid (" SELECT Id_Curhat AS Id, Id_Jadwal, Id_Siswa, Id_Guru, Status_Curhat AS Status FROM Tbl_Curhat WHERE Id_Jadwal = '". @$item->Id ."' ORDER BY Id_Curhat DESC LIMIT 1 ");

                                    if ( @$data_curhat->Id_Jadwal == @$item->Id ) {

                                        @$data_guru = queryid (" SELECT Nama FROM Tbl_Login WHERE IdLogin = '".  @$data_curhat->Id_Guru ."' AND Level = 'Guru' ORDER BY IdLogin DESC LIMIT 1 ");

                                    }
                    
                    ?>

                    <tr>
                        <td>
                            <?= @$nomor++; ?>
                        </td>
                        <td>
                            <?php if ( @$data_curhat->Id_Jadwal == @$item->Id ) { ?>
                            <div>
                                <?php if ( @$data_curhat->Status == 'Menunggu' ) { ?>
                                <a href="?__Module=LihatJadwal&__Crud=Hapus&__Id=<?= @$item->Id; ?>&__IdCurhat=<?= @$data_curhat->Id; ?>"
                                    class="btn btn-danger shadow"
                                    onclick="return confirm('Apakah Anda Yakin Untuk Hapus Data Ini ?')">
                                    Hapus
                                </a>
                                <?php } elseif ( @$data_curhat->Status == 'Validasi' ) { ?>
                                <span class="badge badge-success">
                                    Validasi
                                </span>
                                <?php } elseif ( @$data_curhat->Status == 'Tolak' ) { ?>
                                <span class="badge badge-danger">
                                    Tolak
                                </span>
                                <?php } else { ?>
                                <span class="badge badge-warning">
                                    Tidak Ada Kondisi
                                </span>
                                <?php } ?>
                                <br>
                                <span class="badge bg-primary text-white mt-lg-2">
                                    Guru :
                                    <br>
                                    <?= @$data_guru->Nama; ?>
                                </span>
                            </div>
                            <?php } elseif ( date('H:i') > date('H:i', strtotime( @$item->Jam2 )) ) { ?>
                            <span class="badge badge-danger">
                                Jadwal Sudah Lewat
                            </span>
                            <?php } else { ?>
                            <div>
                                <?php if ( @$data_curhat->Id_Jadwal == FALSE ) { ?>
                                <a href="?__Module=LihatJadwal&__Crud=Tambah&__Id=<?= @$item->Id ?>"
                                    class="btn btn-primary shadow">
                                    Pilih Jadwal
                                </a>
                            </div>
                            <?php } else { ?>
                            <span class="badge badge-info">
                                Sudah Ada Jadwal
                            </span>
                            <?php } ?>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ( @$data_curhat->Status == 'Validasi' AND @$data_curhat->Id_Siswa == @$session_user->Id ) { ?>
                            <div>
                                <a href="?__Module=Konseling&__Id=<?= @$data_curhat->Id ?>"
                                    class="btn btn-primary shadow">
                                    Konseling
                                </a>
                            </div>
                            <?php } else { ?>
                            <div>
                                <span class="badge bg-danger text-white">
                                    Kunci
                                </span>
                            </div>
                            <?php } ?>
                        </td>
                        <td>
                            <?= @$data_kasus->Nama; ?>
                        </td>
                        <td>
                            <?= date('d M Y', strtotime( @$item->Tgl )); ?>
                        </td>
                        <td>
                            <?= date('H:i', strtotime( @$item->Jam1 )); ?>
                            /
                            <?= date('H:i', strtotime( @$item->Jam2 )); ?>
                        </td>
                    </tr>

                    <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php 

    }
    

        if ( isset( $_POST['__BtnSimpan'] ) ) {

            if ( @$_POST['__IdGuru'] == TRUE AND @$_POST['__IdJadwal'] == TRUE AND @$_POST['__IdKasus'] == TRUE ) {

                @$__insert_data = [
                    'Id_Jadwal'     => @$_POST['__IdJadwal'],
                    'Id_Kasus'      => @$_POST['__IdKasus'],
                    'Tanggal'       => date('Y-m-d H:i:s'),
                    'Id_Siswa'      => @$session_user->Id,
                    'Id_Guru'       => @$_POST['__IdGuru'],
                    'Status'        => 'Menunggu'
                ];

                @$__tabel_curhat = __Tabel_Curhat( 'Tambah', '', @$__insert_data );

                if ( @$__tabel_curhat == '200' ) {

                    echo "<script>
                            alert('Berhasil Simpan Data');
                            document.location.href = '?__Module=LihatJadwal';
                        </script>";

                } else {

                    echo "<script>
                            alert('Query Error');
                            document.location.href = '?__Module=LihatJadwal&__Crud=Tambah';
                        </script>";

                }

            } else {

                echo "<script>
                        alert('Isi Form Dengan Benar');
                        document.location.href = '?__Module=LihatJadwal&__Crud=Tambah';
                    </script>";

            }

        }
    
    
?>