<?php

    require_once dirname(dirname(__DIR__)) . '/libary.php';

    require_once dirname(dirname(__DIR__)) . '/header.php';

?>

<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">
        Laporan Konseling
        <br>
        <?= date('d M Y'); ?>
    </h1>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nomor</th>
                            <th>Nama Guru</th>
                            <th>Nama Mahasiswa</th>
                            <th>Nama Kasus</th>
                            <th>Tanggal</th>
                            <th>Jam Curhat</th>
                            <th>Total Pesan</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php 
                    
                        @$nomor = '1';

                        if ( @$session_user->Level == 'Guru' ) {

                            @$__query = " AND Id_Guru = '". @$session_user->Id ."'";

                        } elseif ( @$session_user->Level == 'Siswa' ) {

                            @$__query = " AND Id_Siswa = '". @$session_user->Id ."'";

                        }

                        @$session_item = query (" SELECT Id_Curhat AS Id, Id_Jadwal, Id_Kasus, Tgl_Curhat AS Tgl, Id_Siswa, Id_Guru FROM Tbl_Curhat WHERE Status_Curhat = 'Validasi' ". @$__query ." ORDER BY Id_Curhat DESC ");

                            foreach ( $session_item AS $data => $item ) :

                                @$data_kasus = queryid (" SELECT Nama_Kasus AS Nama FROM Tbl_Kasus WHERE Id_Kasus = '". @$item->Id_Kasus ."' ORDER BY Id_Kasus DESC LIMIT 1 ");

                                @$data_jadwal = queryid (" SELECT Id_Jadwal AS Id, Tgl_Jadwal AS Tgl, JamMulai_Jadwal AS Jam1, JamSelesai_Jadwal AS Jam2 FROM Tbl_Jadwal WHERE Id_Jadwal = '". @$item->Id ."' ORDER BY Id_Jadwal DESC LIMIT 1 ");

                                @$data_guru = queryid (" SELECT IdLogin AS Id, Nama FROM Tbl_Login WHERE IdLogin = '".  @$item->Id_Guru ."' AND Level = 'Guru' ORDER BY IdLogin DESC LIMIT 1 ");

                                @$data_siswa = queryid (" SELECT IdLogin AS Id, Nama FROM Tbl_Login WHERE IdLogin = '".  @$item->Id_Siswa ."' AND Level = 'Siswa' ORDER BY IdLogin DESC LIMIT 1 ");

                                @$data_total_koseling = queryid ("SELECT COUNT( Id_Konseling ) AS Total FROM Tbl_Konseling WHERE Id_Curhat = '". @$item->Id ."' ");
                    
                    ?>

                        <tr>
                            <td>
                                <?= @$nomor++; ?>
                            </td>
                            <td>
                                <?= @$data_guru->Nama; ?>
                            </td>
                            <td>
                                <?= @$data_siswa->Nama; ?>
                            </td>
                            <td>
                                <?= @$data_kasus->Nama; ?>
                            </td>
                            <td>
                                <?= date('d M Y - H:i:s', strtotime( @$item->Tgl )); ?>
                            </td>
                            <td>
                                <?= date('H:i', strtotime( @$data_jadwal->Jam1 )); ?>
                                <br>
                                s/d
                                <br>
                                <?= date('H:i', strtotime( @$data_jadwal->Jam2 )); ?>
                            </td>
                            <td>
                                <?= @$data_total_koseling->Total; ?>
                            </td>
                        </tr>

                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
window.print();
</script>

<?php

    require_once dirname(dirname(__DIR__)) . '/footer.php'; 

?>